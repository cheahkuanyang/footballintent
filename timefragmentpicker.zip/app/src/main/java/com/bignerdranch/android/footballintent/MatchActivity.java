package com.bignerdranch.android.footballintent;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import java.util.UUID;

public class MatchActivity extends SingleFragmentActivity{

    private static final String EXTRA_MATCH_ID=
            "com.bignerdranch.android.footballintent.match_id";

    public static Intent newIntent(Context packageContext, UUID matchId){
        Intent intent = new Intent(packageContext, MatchActivity.class);
        intent.putExtra(EXTRA_MATCH_ID, matchId);
        return intent;
    }

    @Override
    protected Fragment createFragment(){
        UUID matchId= (UUID) getIntent()
                .getSerializableExtra(EXTRA_MATCH_ID);
        return MatchFragment.newInstance(matchId);
    }
}
