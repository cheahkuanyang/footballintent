package com.bignerdranch.android.footballintent;

import java.sql.Time;
import java.util.Date;
import java.util.UUID;

public class Match {
    private UUID mID;
    private String mTitle;
    private Date mDate;
    private boolean mSolved;
    private String mSuspect;
    private Date mTime;

    public Match(){
        //correction
        //mID = UUID.randomUUID();
        this(UUID.randomUUID());
}

    public Match(UUID id){
        mID = id;
        mDate = new Date();
        mTime = new Date();
    }

    //correction
    //public UUID getID() {
    public UUID getId() {
        return mID;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        mDate = date;
    }

    public Date getTime() {
        return mTime;
    }

    public void setTime(Date time) {
        mTime = time;
    }

    public boolean isSolved() {
        return mSolved;
    }

    public void setSolved(boolean solved) {
        mSolved = solved;
    }
    //correction
    //public void getId() {
    //}

    public String getSuspect(){
        return mSuspect;
    }

    public void setSuspect(String suspect){
        mSuspect = suspect;
    }

    public String getPhotoFilename(){
        return "IMG_" + getId().toString() + ".jpg";
    }
}
