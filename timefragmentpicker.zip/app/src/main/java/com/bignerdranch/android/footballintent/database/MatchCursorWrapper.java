package com.bignerdranch.android.footballintent.database;

import android.database.Cursor;
import android.database.CursorWrapper;

import com.bignerdranch.android.footballintent.Match;

import java.util.Date;
import java.util.UUID;

public class MatchCursorWrapper extends CursorWrapper {
    public MatchCursorWrapper(Cursor cursor){
        super(cursor);
    }

    public Match getMatch(){
        String uuidString = getString(getColumnIndex(MatchDbSchema.MatchTable.Cols.UUID));
        String title = getString(getColumnIndex(MatchDbSchema.MatchTable.Cols.TITLE));
        long date = getLong(getColumnIndex(MatchDbSchema.MatchTable.Cols.DATE));
        int isSolved = getInt(getColumnIndex(MatchDbSchema.MatchTable.Cols.SOLVED));
        String suspect = getString(getColumnIndex(MatchDbSchema.MatchTable.Cols.SUSPECT));

        Match match = new Match(UUID.fromString(uuidString));
        match.setTitle(title);
        match.setDate(new Date(date));
        match.setSolved(isSolved !=0);
        match.setSuspect(suspect);



        return match;
    }
}
