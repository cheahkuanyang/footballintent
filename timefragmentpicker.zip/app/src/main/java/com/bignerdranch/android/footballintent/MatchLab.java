package com.bignerdranch.android.footballintent;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.content.FileProvider;

import com.bignerdranch.android.footballintent.database.MatchBaseHelper;
import com.bignerdranch.android.footballintent.database.MatchCursorWrapper;
import com.bignerdranch.android.footballintent.database.MatchDbSchema.MatchTable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MatchLab {
    private static MatchLab sMatchLab;

    private Context mContext;
    private SQLiteDatabase mDatabase;

    public static MatchLab get(Context context) {
        if (sMatchLab == null) {
            sMatchLab = new MatchLab(context);
        }
        return sMatchLab;
    }

    private MatchLab(Context context) {
        mContext = context.getApplicationContext();
        mDatabase = new MatchBaseHelper(mContext)
                .getWritableDatabase();

    }

    public void addMatch(Match m) {
        ContentValues values = getContentValues(m);

        mDatabase.insert(MatchTable.NAME, null, values);
    }

    public List<Match> getMatches() {
        List<Match> matches = new ArrayList<>();

        MatchCursorWrapper cursor = queryMatches(null, null);

        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()){
                matches.add(cursor.getMatch());
                cursor.moveToNext();
            }
        } finally {
            cursor.close();
        }

        return  matches;
    }

    public Match getMatch(UUID id) {
        MatchCursorWrapper cursor = queryMatches(
                MatchTable.Cols.UUID + " = ?",
                new String[] { id.toString() }
        );

        try {
            if (cursor.getCount() == 0){
                return null;
            }

            cursor.moveToFirst();
            return cursor.getMatch();

        }finally {
            cursor.close();
        }

    }

    public File getPhotoFile(Match match){
        File filesDir = mContext.getFilesDir();
        return new File(filesDir, match.getPhotoFilename());
    }

    public void updateMatch(Match match){
        String uuidString = match.getId().toString();
        ContentValues values = getContentValues(match);

        mDatabase.update(MatchTable.NAME, values,
                MatchTable.Cols.UUID + " = ?",
                new String[] { uuidString});
    }

    private MatchCursorWrapper queryMatches(String whereClause, String[] whereArgs){
        Cursor cursor = mDatabase.query(
                MatchTable.NAME,
                null, // columns - null selects all columns
                whereClause,
                whereArgs,
                null, // groupBy
                null, // having
                null  // orderBy
        );
        return new MatchCursorWrapper(cursor);
    }

    private static ContentValues getContentValues(Match match){
        ContentValues values = new ContentValues();
        values.put(MatchTable.Cols.UUID, match.getId().toString());
        values.put(MatchTable.Cols.TITLE, match.getTitle());
        values.put(MatchTable.Cols.DATE, match.getDate().getTime());
        values.put(MatchTable.Cols.SOLVED, match.isSolved() ? 1 : 0);
        values.put(MatchTable.Cols.SUSPECT, match.getSuspect());

        return values;
    }
}


