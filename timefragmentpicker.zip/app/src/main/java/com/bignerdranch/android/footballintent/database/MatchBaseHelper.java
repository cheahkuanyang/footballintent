package com.bignerdranch.android.footballintent.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.bignerdranch.android.footballintent.database.MatchDbSchema.MatchTable;

public class MatchBaseHelper extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "matchBase.db";

    public MatchBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + MatchTable.NAME + "(" + "_id integer primary key autoincrement, "+
                MatchTable.Cols.UUID + "," +
                MatchTable.Cols.TITLE +"," +
                MatchTable.Cols.DATE +"," +
                MatchTable.Cols.SOLVED + "," +
                MatchTable.Cols.SUSPECT +
                ")"
        );

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }
}
